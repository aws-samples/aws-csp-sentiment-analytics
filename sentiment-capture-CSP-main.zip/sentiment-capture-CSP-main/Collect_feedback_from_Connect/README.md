# The Lambda application "Collect_feedback_from_Connect" serves the following functions: 1. it is triggered by an Amazon Connect Cntact Flow, 2. it read the latest sentiment from DynamoDB, 3. it put two objectes in the event bucket
# Variable bucket_name must be updated with the name of the event bucket
