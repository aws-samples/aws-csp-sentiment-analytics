# This is a json file to be uploaded onto Amazon Connect.
