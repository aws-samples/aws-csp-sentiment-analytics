# The  Lambda application "write_engagement_to_S3" serves the following functions: 1. it is triggered by a message being written on a SQS queue, 2. put an object into S3.
